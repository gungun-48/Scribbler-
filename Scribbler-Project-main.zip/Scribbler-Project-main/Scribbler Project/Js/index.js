//  Use to navigate All post page

function AllPost() {
    window.location.href = "html/bloglist.html";
  }
  