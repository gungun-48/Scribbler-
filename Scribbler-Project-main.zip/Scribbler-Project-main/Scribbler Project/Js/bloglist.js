function PostDetailPage() {
    window.location.href = "../html/post.html";
}