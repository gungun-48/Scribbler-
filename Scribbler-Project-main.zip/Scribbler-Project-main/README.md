                                                         SCRIBBLER-PROJECT 
                                                
                                                
                                                
SCRIBBLER IS AN ONLINE PLATFORM FOR COLLABORATIVE WRITING THAT ENABLES ITS USER TO GENERATE, SHARE, AND MODIFY TEXTUAL CONTENT IN REAL-TIME. THE LATEST WEB TECHNOLOGIES HAVE BEEN UTILIZED TO DEVELOP SCRIBBLER, WHICH OFFERS A SMOOTH AND STARIGHTFORWARD INTERFACE, SUITABLE FOR WRITERS WITH VARYING DEGREES OF PROFICIENCY. SCRIBBLER PROVIDES A VARIETY DEGREES OF PROFICIENCY. SCRIBBLER PROVIDES A VARIETY OF FEATURES, INCLUDING VERSION CONTROL, COMMENT FUNCTIONALITY, AND INTEGRATED PUBLISHING OPTIONS, MAKING IT AN IDEAL PLATFORM FOR WRITER'S, EDITOR'S, AND CONTENT CREATORS WHO WANT TO SIMPLIFY THEIR WORK PROCESS AND TEAM UP WITH OTHERS TO ACHIEVE A MORE CREATIVE AND EFFICIENT OUTCOME.                              



![Home Page](https://user-images.githubusercontent.com/115175587/236687749-b06531e1-ae3a-409d-832b-9860a1ea0364.png)


![Sign up Page](https://user-images.githubusercontent.com/115175587/236687986-46c46189-6adb-49e9-8f25-632042a76b34.png)


![Sign in Page](https://user-images.githubusercontent.com/115175587/236687994-4a2387d0-8510-4901-b149-87e4acb5489f.png)


![Create post page](https://user-images.githubusercontent.com/115175587/236687795-4babcf7c-2ae4-4007-8c76-c3a5a75a09ec.png)


![All post page](https://user-images.githubusercontent.com/115175587/236687839-0437504f-3422-4e30-8e63-f9e154a7899b.png)


![Post page](https://user-images.githubusercontent.com/115175587/236688220-d133eb4e-8502-4181-96f3-64b72cab101e.png)


![Delete page](https://user-images.githubusercontent.com/115175587/236687868-ceddc5ef-8340-4431-87f9-7c623c2a4f46.png)
